package com.jarvis.app

import android.content.Context
import org.json.JSONArray

object Config {
    /** Modelo de IA. Puedes cambiarlo por "claude-sonnet-5-5" para respuestas más inteligentes (cuesta más). */
    const val MODEL = "claude-haiku-5-5"

    /** Código de país para WhatsApp cuando el contacto está guardado como 09xxxxxxxx (593 = Ecuador). */
    const val DEFAULT_COUNTRY_CODE = "593"

    private const val MAX_HISTORY = 24

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun apiKey(ctx: Context): String = prefs(ctx).getString("api_key", "")?.trim().orEmpty()

    fun setApiKey(ctx: Context, key: String) {
        prefs(ctx).edit().putString("api_key", key.trim()).apply()
    }

    fun loadHistory(ctx: Context): JSONArray = try {
        JSONArray(prefs(ctx).getString("history", "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    fun saveHistory(ctx: Context, history: JSONArray) {
        val trimmed = JSONArray()
        val start = maxOf(0, history.length() - MAX_HISTORY)
        for (i in start until history.length()) trimmed.put(history.get(i))
        prefs(ctx).edit().putString("history", trimmed.toString()).apply()
    }

    fun clearHistory(ctx: Context) {
        prefs(ctx).edit().remove("history").apply()
    }
}
