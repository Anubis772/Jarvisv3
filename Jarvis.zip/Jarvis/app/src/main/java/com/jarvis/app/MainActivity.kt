package com.jarvis.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.util.Base64
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var speaker: Speaker
    private lateinit var processor: CommandProcessor
    private lateinit var agent: AiAgent
    private var recognizer: SpeechRecognizer? = null
    private val executor = Executors.newSingleThreadExecutor()

    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var scroll: ScrollView
    private lateinit var btnTalk: Button
    private lateinit var btnContinuous: Button
    private lateinit var btnNotif: Button
    private lateinit var btnCamera: Button
    private lateinit var btnKey: Button
    private lateinit var btnForget: Button

    private val handler = Handler(Looper.getMainLooper())
    private var listening = false
    private var speaking = false
    private var continuous = false
    private var resumed = false
    private var pendingQuestion: String? = null

    private val visionWords = listOf(
        "mira esto", "mira eso", "mira esta", "mira este", "que es esto", "que ves",
        "que hay aqui", "describe esto", "describe lo que ves", "traduce esto", "traduce este",
        "traduce ese", "traduce el cartel", "analiza esto", "analiza este", "lee este",
        "lee esta", "lee esto", "lee el cartel"
    )

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (!hasMic()) addLog("Sin permiso de micrófono no puedo escucharte.")
        }

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok -> onPhotoTaken(ok) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        pendingQuestion = savedInstanceState?.getString("pending")

        tvStatus = findViewById(R.id.tvStatus)
        tvLog = findViewById(R.id.tvLog)
        scroll = findViewById(R.id.scroll)
        btnTalk = findViewById(R.id.btnTalk)
        btnContinuous = findViewById(R.id.btnContinuous)
        btnNotif = findViewById(R.id.btnNotif)
        btnCamera = findViewById(R.id.btnCamera)
        btnKey = findViewById(R.id.btnKey)
        btnForget = findViewById(R.id.btnForget)

        processor = CommandProcessor(this)
        val actions = Actions(this, processor)
        processor.actions = actions
        agent = AiAgent(this, actions)

        speaker = Speaker(this) {
            runOnUiThread {
                reply(
                    if (Config.apiKey(this).isBlank())
                        "Jarvis en línea. Para conversar conmigo, pulsa el botón clave e introduce tu clave de la IA. Mientras tanto entiendo órdenes básicas."
                    else
                        "Jarvis en línea. ¿En qué puedo ayudarle?"
                )
            }
        }
        speaker.finished = {
            runOnUiThread {
                speaking = false
                if (continuous) startListening()
            }
        }

        btnTalk.setOnClickListener {
            if (speaking) { speaker.stop(); speaking = false }
            if (listening) recognizer?.stopListening() else startListening()
        }

        btnContinuous.setOnClickListener {
            continuous = !continuous
            if (continuous) {
                btnContinuous.text = "Modo continuo: ACTIVADO (di «Jarvis…»)"
                startListening()
            } else {
                btnContinuous.text = "Modo continuo: apagado"
                handler.removeCallbacksAndMessages(null)
                recognizer?.cancel()
                listening = false
                setStatus("Listo")
            }
        }

        btnNotif.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btnCamera.setOnClickListener { requestVision("Describe brevemente lo que ves.") }
        btnKey.setOnClickListener { askApiKey() }
        btnForget.setOnClickListener {
            Config.clearHistory(this)
            addLog("Jarvis: He olvidado nuestra conversación anterior.")
        }

        if (!hasMic() || !hasPerm(Manifest.permission.READ_SMS)) requestPerms()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("pending", pendingQuestion)
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        val enabled = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        btnNotif.text = if (enabled) "Notificaciones: activadas ✓" else "Activar lectura de notificaciones"
        if (continuous && !speaking) startListening()
    }

    override fun onPause() {
        super.onPause()
        resumed = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        listening = false
    }

    // ---------- Escuchar ----------
    private fun startListening() {
        if (!resumed) return
        if (!hasMic()) { requestPerms(); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            reply("Tu teléfono no tiene reconocimiento de voz. Instala o actualiza la aplicación Google.")
            return
        }
        if (listening || speaking) return
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        listening = true
        setStatus("Escuchando…")
        r.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.let { setStatus("… $it") }
        }

        override fun onError(error: Int) {
            listening = false
            setStatus("Listo")
            if (continuous && error != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                handler.postDelayed({ if (continuous) startListening() }, 700)
            }
        }

        override fun onResults(results: Bundle?) {
            listening = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty()
            handleText(text)
        }
    }

    private fun handleText(text: String) {
        setStatus("Listo")
        val ignore = text.isBlank() || (continuous && !CommandProcessor.hasWakeWord(text))
        if (ignore) {
            if (continuous) handler.postDelayed({ if (continuous) startListening() }, 300)
            return
        }
        addLog("Tú: $text")
        route(text)
    }

    // ---------- Decidir qué hacer con lo que dijiste ----------
    private fun route(text: String) {
        val normalized = CommandProcessor.normalize(text)
        if (visionWords.any { normalized.contains(it) }) {
            requestVision(text)
            return
        }
        if (Config.apiKey(this).isBlank()) {
            reply(processor.process(text))
            return
        }
        setStatus("Pensando…")
        executor.execute {
            val answer = askAi(text, null)
            runOnUiThread { setStatus("Listo"); reply(answer) }
        }
    }

    /** Llamar desde un hilo secundario. */
    private fun askAi(text: String, imageProvider: (() -> String)?): String = try {
        agent.ask(text, imageProvider?.invoke())
    } catch (e: ApiException) {
        e.userMessage
    } catch (e: IOException) {
        if (imageProvider == null) "Sin conexión con la IA. " + processor.process(text)
        else "Sin conexión con la IA. No puedo analizar la foto."
    } catch (e: Exception) {
        "Ocurrió un error: ${e.message}"
    }

    // ---------- Cámara ----------
    private fun photoFile(): File = File(File(cacheDir, "photos").apply { mkdirs() }, "foto.jpg")

    private fun requestVision(question: String) {
        if (Config.apiKey(this).isBlank()) {
            reply("Para usar la cámara necesito la clave de la IA. Pulsa el botón clave.")
            return
        }
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        listening = false
        pendingQuestion = question
        val file = photoFile()
        file.delete()
        val uri = FileProvider.getUriForFile(this, "com.jarvis.app.fileprovider", file)
        cameraLauncher.launch(uri)
    }

    private fun onPhotoTaken(ok: Boolean) {
        if (!ok) {
            reply("No se tomó la foto.")
            return
        }
        val question = pendingQuestion ?: "Describe brevemente lo que ves."
        pendingQuestion = null
        setStatus("Analizando…")
        executor.execute {
            val answer = askAi(question) { photoToBase64(photoFile()) }
            runOnUiThread { setStatus("Listo"); reply(answer) }
        }
    }

    private fun photoToBase64(file: File): String {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
        var bmp = BitmapFactory.decodeFile(
            file.absolutePath,
            BitmapFactory.Options().apply { inSampleSize = sample }
        ) ?: throw IOException("No pude leer la foto")

        val degrees = when (
            ExifInterface(file.absolutePath)
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        ) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees != 0f) {
            bmp = Bitmap.createBitmap(
                bmp, 0, 0, bmp.width, bmp.height,
                Matrix().apply { postRotate(degrees) }, true
            )
        }
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    // ---------- Clave de la IA ----------
    private fun askApiKey() {
        val input = EditText(this).apply {
            hint = "sk-ant-..."
            setText(Config.apiKey(this@MainActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle("Clave de API de Anthropic")
            .setMessage("Se guarda solo en este teléfono. Se crea en console.anthropic.com")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                Config.setApiKey(this, input.text.toString())
                addLog("Jarvis: Clave guardada. Ya puedes conversar conmigo.")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Hablar ----------
    private fun reply(text: String) {
        addLog("Jarvis: $text")
        speaking = speaker.speak(text)
        if (!speaking && continuous) handler.postDelayed({ if (continuous) startListening() }, 700)
    }

    // ---------- Utilidades ----------
    private fun addLog(line: String) {
        tvLog.append(line + "\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setStatus(s: String) { tvStatus.text = s }

    private fun hasPerm(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun hasMic() = hasPerm(Manifest.permission.RECORD_AUDIO)

    private fun requestPerms() {
        permLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_SMS,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE
            )
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        speaker.shutdown()
        executor.shutdown()
    }
}
