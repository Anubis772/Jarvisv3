package com.jarvis.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class NotifItem(val app: String, val title: String, val text: String)

/** Guarda las últimas notificaciones (WhatsApp, Telegram, etc.) para que Jarvis las lea. */
class JarvisNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        synchronized(store) {
            store.add(0, NotifItem(app, title, text))
            while (store.size > 30) store.removeAt(store.size - 1)
        }
    }

    companion object {
        private val store = mutableListOf<NotifItem>()
        fun snapshot(): List<NotifItem> = synchronized(store) { store.toList() }
    }
}
