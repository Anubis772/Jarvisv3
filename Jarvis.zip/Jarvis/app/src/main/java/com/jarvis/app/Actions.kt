package com.jarvis.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

/** Acciones reales sobre el teléfono que la IA puede pedir. */
class Actions(private val ctx: Context, private val processor: CommandProcessor) {

    /** Si ya se leyeron mensajes/notificaciones en esta orden, no se llama sola (anti-engaños). */
    @Volatile
    var untrustedSeen = false

    fun runTool(name: String, i: JSONObject): String {
        return try {
            when (name) {
                "abrir_app" -> processor.openApp(CommandProcessor.normalize(i.getString("nombre")))
                "leer_sms" -> { untrustedSeen = true; processor.readSms() }
                "leer_notificaciones" -> {
                    untrustedSeen = true
                    processor.readNotifications(CommandProcessor.normalize(i.optString("app")))
                }
                "bateria" -> processor.battery()
                "poner_alarma" -> alarma(i.getInt("hora"), i.optInt("minutos", 0), i.optString("mensaje"))
                "poner_temporizador" -> temporizador(i.getInt("segundos"), i.optString("mensaje"))
                "crear_evento" -> evento(i.getString("titulo"), i.getString("inicio"), i.optInt("duracion_minutos", 60))
                "ajustar_volumen" -> volumen(i.getInt("porcentaje"))
                "ajustar_brillo" -> brillo(i.getInt("porcentaje"))
                "linterna" -> linterna(i.optBoolean("encendida", true))
                "llamar" -> llamar(i.getString("contacto"))
                "whatsapp" -> whatsapp(i.getString("contacto"), i.getString("mensaje"))
                "abrir_ajustes" -> ajustes(i.optString("seccion"))
                else -> "Herramienta desconocida: $name"
            }
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

    private fun start(intent: Intent) {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun hasPerm(p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    // ---------- Alarmas, temporizador, calendario ----------
    fun alarma(h: Int, m: Int, msg: String): String {
        if (h !in 0..23 || m !in 0..59) return "Hora no válida."
        start(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_MESSAGE, msg.ifBlank { "Jarvis" })
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "Alarma puesta a las %02d:%02d.".format(h, m)
    }

    fun temporizador(seconds: Int, msg: String): String {
        if (seconds !in 1..86400) return "Duración no válida."
        start(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, msg.ifBlank { "Jarvis" })
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "Temporizador iniciado."
    }

    private fun evento(title: String, inicio: String, minutes: Int): String {
        val begin = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(inicio)?.time
            ?: return "Fecha no válida."
        start(
            Intent(Intent.ACTION_INSERT)
                .setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, title)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + minutes * 60_000L)
        )
        return "Abrí el calendario con el evento. Pulsa guardar para confirmarlo."
    }

    // ---------- Volumen, brillo, linterna ----------
    fun volumen(pct: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val level = (pct.coerceIn(0, 100) * max) / 100
        am.setStreamVolume(AudioManager.STREAM_MUSIC, level, AudioManager.FLAG_SHOW_UI)
        return "Volumen al ${pct.coerceIn(0, 100)} por ciento."
    }

    fun brillo(pct: Int): String {
        if (!Settings.System.canWrite(ctx)) {
            start(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
            )
            return "Necesito permiso para modificar ajustes del sistema. Actívalo en la pantalla que abrí y repite la orden."
        }
        val p = pct.coerceIn(1, 100)
        Settings.System.putInt(
            ctx.contentResolver,
            Settings.System.SCREEN_BRIGHTNESS_MODE,
            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        )
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, p * 255 / 100)
        return "Brillo al $p por ciento."
    }

    fun volumenRelativo(delta: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val current = am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
        return volumen(current + delta)
    }

    fun brilloRelativo(delta: Int): String {
        val current = Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) * 100 / 255
        return brillo(current + delta)
    }

    fun linterna(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Este teléfono no tiene linterna disponible."
        cm.setTorchMode(id, on)
        return if (on) "Linterna encendida." else "Linterna apagada."
    }

    // ---------- Llamadas y WhatsApp ----------
    private fun resolveNumber(target: String): String? {
        val direct = target.filter { it.isDigit() || it == '+' }
        if (direct.count { it.isDigit() } >= 6 && target.none { it.isLetter() }) return direct
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) return null

        val wanted = CommandProcessor.normalize(target)
        var partial: String? = null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val num = c.getString(0) ?: continue
                val nm = CommandProcessor.normalize(c.getString(1) ?: "")
                if (nm == wanted) return num
                if (partial == null && nm.contains(wanted)) partial = num
            }
        }
        return partial
    }

    fun llamar(target: String): String {
        val number = resolveNumber(target) ?: return "No encontré a $target en tus contactos."
        val canCall = hasPerm(Manifest.permission.CALL_PHONE) && !untrustedSeen
        start(Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
        return if (canCall) "Llamando a $target." else "Abrí el teclado con el número de $target. Pulsa llamar."
    }

    private fun waNumber(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        return when {
            raw.trim().startsWith("+") -> digits
            digits.startsWith("00") -> digits.drop(2)
            digits.startsWith("0") -> Config.DEFAULT_COUNTRY_CODE + digits.drop(1)
            else -> digits
        }
    }

    fun whatsapp(target: String, msg: String): String {
        val raw = resolveNumber(target) ?: return "No encontré a $target en tus contactos."
        val uri = Uri.parse("https://wa.me/${waNumber(raw)}?text=" + Uri.encode(msg))
        val base = Intent(Intent.ACTION_VIEW, uri)
        try {
            start(Intent(base).setPackage("com.whatsapp"))
        } catch (e: ActivityNotFoundException) {
            try {
                start(Intent(base).setPackage("com.whatsapp.w4b"))
            } catch (e2: ActivityNotFoundException) {
                start(base)
            }
        }
        return "Abrí WhatsApp con el mensaje para $target. Pulsa enviar."
    }

    // ---------- Wi-Fi / Bluetooth (solo se puede abrir la pantalla) ----------
    fun ajustes(section: String): String {
        val action = when (CommandProcessor.normalize(section)) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "pantalla" -> Settings.ACTION_DISPLAY_SETTINGS
            "sonido" -> Settings.ACTION_SOUND_SETTINGS
            "ubicacion" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        start(Intent(action))
        return "Abrí los ajustes. Android no me deja activarlo por ti; hazlo con un toque."
    }
}
