package com.jarvis.app

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.ContactsContract
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Entiende las órdenes en español y devuelve lo que Jarvis debe responder. */
class CommandProcessor(private val ctx: Context) {

    private val aliases = mapOf(
        "ajustes" to listOf("configuracion", "ajustes", "settings"),
        "configuracion" to listOf("configuracion", "ajustes", "settings"),
        "camara" to listOf("camara", "camera"),
        "galeria" to listOf("galeria", "fotos", "gallery", "photos"),
        "calculadora" to listOf("calculadora", "calculator"),
        "reloj" to listOf("reloj", "clock"),
        "telefono" to listOf("telefono", "phone", "llamadas"),
        "mensajes" to listOf("mensajes", "messages", "sms"),
        "contactos" to listOf("contactos", "contacts"),
        "navegador" to listOf("chrome", "navegador", "browser"),
        "internet" to listOf("chrome", "navegador", "browser"),
        "mapas" to listOf("maps", "mapas"),
        "tienda" to listOf("play store", "tienda"),
        "musica" to listOf("musica", "music", "spotify")
    )

    fun process(raw: String): String {
        var t = normalize(raw)
        for (w in WAKE_WORDS) t = t.replace(w, " ")
        t = t.replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty()) return "A sus órdenes."

        deviceCommand(t)?.let { return it }

        val openRegex = Regex(
            "^(abre|abrir|abreme|inicia|lanza|ejecuta)\\s+" +
                "(?:(?:la|el|las|los|mi)\\s+)?(?:(?:aplicacion|app)\\s+(?:de\\s+)?)?"
        )

        return when {
            openRegex.containsMatchIn(t) -> openApp(t.replace(openRegex, "").trim())
            Regex("\\bhora\\b").containsMatchIn(t) ->
                "Son las " + SimpleDateFormat("HH:mm", Locale("es")).format(Date())
            t.contains("fecha") || t.contains("que dia") ->
                "Hoy es " + SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy", Locale("es")).format(Date())
            t.contains("bateria") -> battery()
            t.contains("notificacion") || KNOWN_APPS.any { t.contains(it) } -> readNotifications(t)
            t.contains("mensaje") || t.contains("sms") -> readSms()
            t.contains("ayuda") || t.contains("que puedes") ->
                "Puedo abrir aplicaciones, leer tus mensajes y notificaciones, poner alarmas y temporizadores, " +
                    "cambiar volumen y brillo, encender la linterna, llamar, escribir por WhatsApp, " +
                    "y decirte la hora, la fecha y la batería. " +
                    "Prueba: abre WhatsApp."
            t.contains("hola") || t.contains("buenas") || t.contains("buenos") ->
                "A sus órdenes. ¿En qué puedo ayudarle?"
            else -> "No entendí la orden. Di ayuda para ver lo que puedo hacer."
        }
    }

    // ---------- Órdenes de control del teléfono (modo sin IA) ----------
    var actions: Actions? = null

    private fun has(t: String, w: String) = Regex("\\b$w\\b").containsMatchIn(t)

    private fun parseTime(t: String): Pair<Int, Int>? {
        val m = Regex("\\b(\\d{1,2})(?:\\s+y)?(?:\\s+(\\d{2}|media|cuarto))?\\b").find(t) ?: return null
        var h = m.groupValues[1].toInt()
        val min = when (val x = m.groupValues[2]) {
            "" -> 0
            "media" -> 30
            "cuarto" -> 15
            else -> x.toInt()
        }
        val pm = t.contains("tarde") || t.contains("noche") || Regex("\\bp m\\b|\\bpm\\b").containsMatchIn(t)
        if (pm && h in 1..11) h += 12
        if (t.contains("noche") && h == 12) h = 0
        if (h !in 0..23 || min !in 0..59) return null
        return h to min
    }

    /** Devuelve la respuesta si la frase es una orden de control del teléfono; si no, null. */
    private fun deviceCommand(t: String): String? {
        val a = actions ?: return null

        // "escríbele a Juan por whatsapp que llego tarde"
        Regex("^(?:mandale|enviale|escribele|manda|envia|escribe)\\b.*?\\ba\\s+(.+?)\\s+(?:que|diciendo)\\s+(.+)$")
            .find(t)?.let { m ->
                val name = m.groupValues[1].replace(Regex("\\s+por\\s+(whatsapp|mensaje)$"), "").trim()
                return a.whatsapp(name, m.groupValues[2].trim())
            }

        // "llama a mamá"
        Regex("^(?:llama|llamar|llamame|marca)\\s+(?:a\\s+)?(.+)$").find(t)?.let { m ->
            return a.llamar(m.groupValues[1].trim())
        }

        if (t.contains("alarma") || t.contains("despiertame")) {
            val tm = parseTime(t)
                ?: return "¿A qué hora quieres la alarma? Di, por ejemplo: alarma a las 6 y media."
            return a.alarma(tm.first, tm.second, "")
        }

        if (t.contains("temporizador") || t.contains("cronometro") || t.contains("avisame en")) {
            val m = Regex("(\\d+)\\s*(segundo|minuto|hora)").find(t)
            val secs = when {
                m != null -> (m.groupValues[1].toIntOrNull() ?: 0) *
                    when (m.groupValues[2]) { "segundo" -> 1; "minuto" -> 60; else -> 3600 }
                t.contains("media hora") -> 1800
                else -> return "¿De cuánto tiempo? Di, por ejemplo: temporizador de 10 minutos."
            }
            return a.temporizador(secs, "")
        }

        if (t.contains("volumen")) {
            val n = Regex("(\\d{1,3})").find(t)?.groupValues?.get(1)?.toIntOrNull()
            return when {
                n != null -> a.volumen(n)
                t.contains("maximo") -> a.volumen(100)
                t.contains("minimo") || t.contains("silencio") -> a.volumen(0)
                has(t, "sube") || has(t, "mas") || has(t, "aumenta") -> a.volumenRelativo(15)
                has(t, "baja") || has(t, "menos") || has(t, "disminuye") -> a.volumenRelativo(-15)
                else -> "¿Qué volumen quieres? Di, por ejemplo: volumen al 50."
            }
        }
        if (has(t, "silencia") || t.contains("modo silencio")) return a.volumen(0)

        if (t.contains("brillo")) {
            val n = Regex("(\\d{1,3})").find(t)?.groupValues?.get(1)?.toIntOrNull()
            return when {
                n != null -> a.brillo(n)
                t.contains("maximo") -> a.brillo(100)
                t.contains("minimo") -> a.brillo(1)
                has(t, "sube") || has(t, "mas") || has(t, "aumenta") -> a.brilloRelativo(20)
                has(t, "baja") || has(t, "menos") || has(t, "disminuye") -> a.brilloRelativo(-20)
                else -> "¿Qué brillo quieres? Di, por ejemplo: brillo al 50."
            }
        }

        if (t.contains("linterna") || has(t, "flash")) {
            val off = has(t, "apaga") || has(t, "apagar") || has(t, "desactiva") || has(t, "cierra")
            return a.linterna(!off)
        }

        if (Regex("wi ?fi").containsMatchIn(t) || t.contains("bluetooth")) {
            return a.ajustes(if (t.contains("bluetooth")) "bluetooth" else "wifi")
        }
        return null
    }

    // ---------- Abrir aplicaciones ----------
    fun openApp(name: String): String {
        if (name.isBlank()) return "¿Qué aplicación quieres abrir?"
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val candidates = aliases[name] ?: listOf(name)
        val labeled = apps.map { it to normalize(it.loadLabel(pm).toString()) }

        val match = labeled.firstOrNull { (_, l) -> candidates.any { it == l } }
            ?: labeled.firstOrNull { (_, l) ->
                candidates.any { c -> l.contains(c) || (l.length >= 4 && c.contains(l)) }
            }
            ?: return "No encontré una aplicación llamada $name."

        val info = match.first.activityInfo
        val launch = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(info.packageName, info.name))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(launch)
            "Abriendo " + match.first.loadLabel(pm)
        } catch (e: Exception) {
            "No pude abrir esa aplicación."
        }
    }

    // ---------- Notificaciones (WhatsApp, Telegram, ...) ----------
    fun readNotifications(t: String): String {
        if (!NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)) {
            return "Necesito acceso a las notificaciones. Pulsa el botón de activar notificaciones."
        }
        val all = JarvisNotificationListener.snapshot()
        val wanted = KNOWN_APPS.firstOrNull { t.contains(it) }
        val list = if (wanted != null) all.filter { normalize(it.app).contains(wanted) } else all
        if (list.isEmpty()) {
            return if (wanted != null) "No tengo notificaciones recientes de $wanted."
            else "No tienes notificaciones nuevas."
        }
        val items = list.take(5).joinToString(". ") { "${it.app}, de ${it.title}: ${it.text.take(200)}" }
        return "Tienes ${list.size} notificaciones. $items"
    }

    // ---------- SMS ----------
    fun readSms(): String {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) return "Necesito permiso para leer tus mensajes SMS."
        val out = mutableListOf<String>()
        try {
            ctx.contentResolver.query(
                Uri.parse("content://sms/inbox"),
                arrayOf("address", "body"), null, null, "date DESC LIMIT 3"
            )?.use { c ->
                while (c.moveToNext()) {
                    val addr = c.getString(0) ?: "desconocido"
                    val body = c.getString(1) ?: ""
                    out.add("De ${contactName(addr) ?: addr}: ${body.take(200)}")
                }
            }
        } catch (e: Exception) {
            return "No pude leer tus mensajes."
        }
        return if (out.isEmpty()) "No tienes mensajes SMS." else "Tus últimos mensajes. " + out.joinToString(". ")
    }

    private fun contactName(number: String): String? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) return null
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
            )
            ctx.contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- Batería ----------
    fun battery(): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "La batería está al $level por ciento."
    }

    companion object {
        private val WAKE_WORDS = listOf("jarvis", "yarvis", "jarbis", "yarbis", "charvis", "jarvi")
        private val KNOWN_APPS = listOf("whatsapp", "telegram", "messenger", "instagram", "facebook", "gmail")

        fun normalize(s: String): String =
            Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
                .replace(Regex("\\p{M}+"), "")
                .replace(Regex("[^a-z0-9 ]"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()

        fun hasWakeWord(raw: String): Boolean {
            val n = normalize(raw)
            return WAKE_WORDS.any { n.contains(it) }
        }
    }
}
