package com.jarvis.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Voz de Jarvis (texto a voz). */
class Speaker(context: Context, private val onReady: () -> Unit) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false

    /** Se llama (en un hilo secundario) cuando Jarvis termina de hablar. */
    var finished: (() -> Unit)? = null

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val r = tts.setLanguage(Locale("es"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.getDefault())
        }
        tts.setSpeechRate(1.0f)
        tts.setPitch(0.9f)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { finished?.invoke() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { finished?.invoke() }
        })
        ready = true
        onReady()
    }

    /** Devuelve false si la voz aún no está lista. */
    fun speak(text: String): Boolean {
        if (!ready) return false
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        return true
    }

    fun stop() { tts.stop() }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
