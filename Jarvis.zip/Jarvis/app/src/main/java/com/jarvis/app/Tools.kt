package com.jarvis.app

import org.json.JSONArray
import org.json.JSONObject

/** Herramientas que la IA puede usar para controlar el teléfono. */
object Tools {

    private fun s(desc: String) = JSONObject().put("type", "string").put("description", desc)
    private fun n(desc: String) = JSONObject().put("type", "integer").put("description", desc)
    private fun b(desc: String) = JSONObject().put("type", "boolean").put("description", desc)

    private fun obj(vararg props: Pair<String, JSONObject>): JSONObject {
        val p = JSONObject()
        props.forEach { p.put(it.first, it.second) }
        return p
    }

    private fun tool(
        name: String,
        desc: String,
        props: JSONObject = JSONObject(),
        required: List<String> = emptyList()
    ): JSONObject = JSONObject()
        .put("name", name)
        .put("description", desc)
        .put(
            "input_schema",
            JSONObject()
                .put("type", "object")
                .put("properties", props)
                .put("required", JSONArray(required))
        )

    fun definitions(): JSONArray = JSONArray().apply {
        put(tool("abrir_app", "Abre una aplicación instalada en el teléfono.",
            obj("nombre" to s("Nombre de la app, por ejemplo WhatsApp, Cámara, Ajustes, YouTube")),
            listOf("nombre")))
        put(tool("leer_sms", "Lee en voz alta los últimos mensajes SMS recibidos."))
        put(tool("leer_notificaciones",
            "Lee las notificaciones recientes (WhatsApp, Telegram, Gmail, etc.).",
            obj("app" to s("Opcional: solo notificaciones de esta app, por ejemplo whatsapp"))))
        put(tool("bateria", "Dice el nivel de batería del teléfono."))
        put(tool("poner_alarma", "Programa una alarma o recordatorio a una hora del día (formato 24 horas).",
            obj("hora" to n("Hora 0-23"), "minutos" to n("Minutos 0-59"), "mensaje" to s("Etiqueta de la alarma")),
            listOf("hora")))
        put(tool("poner_temporizador", "Inicia una cuenta regresiva.",
            obj("segundos" to n("Duración en segundos"), "mensaje" to s("Etiqueta")),
            listOf("segundos")))
        put(tool("crear_evento", "Abre el calendario con un evento listo para guardar.",
            obj("titulo" to s("Título del evento"),
                "inicio" to s("Fecha y hora local de inicio, formato YYYY-MM-DDTHH:MM"),
                "duracion_minutos" to n("Duración en minutos, por defecto 60")),
            listOf("titulo", "inicio")))
        put(tool("ajustar_volumen", "Cambia el volumen multimedia.",
            obj("porcentaje" to n("0 a 100")), listOf("porcentaje")))
        put(tool("ajustar_brillo", "Cambia el brillo de la pantalla.",
            obj("porcentaje" to n("1 a 100")), listOf("porcentaje")))
        put(tool("linterna", "Enciende o apaga la linterna.",
            obj("encendida" to b("true para encender, false para apagar")), listOf("encendida")))
        put(tool("llamar", "Llama por teléfono a un contacto o número. Úsala solo si el usuario lo pidió.",
            obj("contacto" to s("Nombre del contacto o número")), listOf("contacto")))
        put(tool("whatsapp",
            "Abre un chat de WhatsApp con el mensaje escrito; el usuario debe pulsar enviar. Úsala solo si el usuario lo pidió.",
            obj("contacto" to s("Nombre del contacto o número"), "mensaje" to s("Texto del mensaje")),
            listOf("contacto", "mensaje")))
        put(tool("abrir_ajustes",
            "Abre la pantalla de ajustes. Android no permite activar Wi-Fi ni Bluetooth desde una app, así que úsala para eso.",
            obj("seccion" to s("wifi, bluetooth, pantalla, sonido, ubicacion o general")),
            listOf("seccion")))
    }
}
