# Jarvis v3 (Android, Kotlin)

Asistente de voz en español. Dos modos:

- **Sin clave de IA (gratis, sin API):** órdenes fijas por voz. Abrir apps, leer SMS y notificaciones, alarmas,
  temporizador, volumen, brillo, linterna, llamar, WhatsApp, hora, fecha y batería.
- **Con clave de IA (Claude):** además conversa con memoria, entiende frases libres y analiza fotos con la cámara.

## Estructura

```
Jarvis/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/jarvis/app/
        │   ├── MainActivity.kt                 (pantalla, micrófono, cámara, flujo)
        │   ├── CommandProcessor.kt             (órdenes sin IA)
        │   ├── Actions.kt                      (alarmas, volumen, brillo, llamadas, WhatsApp...)
        │   ├── AiAgent.kt                      (conversación con Claude + memoria)
        │   ├── Tools.kt                        (herramientas que la IA puede usar)
        │   ├── Config.kt                       (modelo, código de país, clave y memoria)
        │   ├── Speaker.kt                      (voz)
        │   └── JarvisNotificationListener.kt   (lee notificaciones)
        └── res/
            ├── layout/activity_main.xml
            ├── drawable/ic_jarvis.xml
            ├── xml/file_paths.xml
            └── values/{strings.xml, themes.xml}
```

## Obtener el APK sin PC (GitHub)

1. Crea una cuenta y un repositorio nuevo en github.com.
2. Sube este ZIP tal cual: *Add file > Upload files*.
3. Pestaña *Actions > set up a workflow yourself*, pega el contenido de `build-apk.yml` y guarda (Commit).
4. Cuando termine la ejecución (unos minutos), entra en ella y descarga **Jarvis-APK**. Descomprime y abre `app-debug.apk`.

Con PC: abre la carpeta `Jarvis` en Android Studio y usa *Build > Build APK(s)*.

## Primer uso

1. Acepta los permisos (micrófono, SMS, contactos, teléfono).
2. Pulsa «Activar lectura de notificaciones» y habilita Jarvis.
3. Si Android bloquea un permiso: Ajustes > Aplicaciones > Jarvis > ⋮ > «Permitir ajustes restringidos».
4. Para el brillo, la primera vez Android pedirá «Modificar ajustes del sistema».
5. Mantén la app **Google** actualizada y descarga el español sin conexión (Ajustes > Google > Voz) para usarlo sin internet.
6. Opcional: «🔑 Clave IA» para activar la conversación (se crea en console.anthropic.com; tiene costo por uso).

## Ajustes en `Config.kt`

- `MODEL`: `claude-haiku-5-5` (rápido y barato). Para respuestas más inteligentes: `claude-sonnet-5-5`.
- `DEFAULT_COUNTRY_CODE`: `593` (Ecuador), para WhatsApp con contactos guardados como 09xxxxxxxx.

## Órdenes de ejemplo (funcionan sin IA)

- «Jarvis, abre WhatsApp» / «lee mis mensajes» / «lee las notificaciones»
- «Alarma a las 6 y media» / «temporizador de 10 minutos»
- «Volumen al 70» / «sube el volumen» / «brillo al 30» / «enciende la linterna»
- «Llama a mamá» / «escríbele a Juan por WhatsApp que llego tarde» (tú pulsas enviar)
- «Activa el Wi-Fi» → abre los ajustes (Android no deja activarlo desde una app)
- «¿Qué hora es?» / «¿Qué día es hoy?» / «¿Cuánta batería tengo?»
- Modo continuo: empieza con «Jarvis, …»
