# JARVIS para Infinix HOT 50i (Termux)

Asistente de voz ligero optimizado para 4 GB de RAM.

## Qué puede hacer
- Escuchar (termux-speech-to-text)
- Hablar (termux-tts-speak)
- Abrir aplicaciones por voz
- Decir la hora, batería, etc.
- Enviar comandos básicos
- Responder de forma conversacional (opcional con API gratuita)

## Requisitos
1. Termux (desde F-Droid, NO desde Play Store)
2. Termux:API (desde F-Droid)
3. Permisos de micrófono y almacenamiento a Termux y Termux:API

## Instalación rápida
1. Copia esta carpeta completa a tu teléfono (o descarga el ZIP)
2. Abre Termux
3. Ejecuta:

```bash
cd /sdcard/Download   # o la ruta donde esté el ZIP descomprimido
cd Jarvis-Termux
bash install.sh
```

4. Para iniciar Jarvis:
```bash
jarvis
```

o

```bash
python jarvis.py
```

## Comandos de ejemplo
- "abrir whatsapp"
- "abrir youtube"
- "abrir cámara"
- "qué hora es"
- "batería"
- "hola jarvis"
- "apagar" o "salir"

## Personalizar apps
Edita el archivo `config/apps.json` y agrega más aplicaciones con su package name.

Para encontrar el package name de una app:
```bash
pm list packages | grep -i nombre
```

## Notas importantes
- Este Jarvis es ligero y funciona bien en 4 GB.
- No puede leer mensajes de WhatsApp automáticamente (eso requiere Accessibility Service de una app nativa).
- Para un Jarvis más potente usa Open Jarvis (proyecto Kotlin) desde GitHub.
