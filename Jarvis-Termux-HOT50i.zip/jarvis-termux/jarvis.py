#!/data/data/com.termux/files/usr/bin/python
# -*- coding: utf-8 -*-
"""
JARVIS ligero para Termux
Optimizado para Infinix HOT 50i (4 GB RAM)
"""

import subprocess
import json
import os
import time
import re
from datetime import datetime

# Rutas
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APPS_FILE = os.path.join(BASE_DIR, "config", "apps.json")

# Cargar apps
try:
    with open(APPS_FILE, "r", encoding="utf-8") as f:
        APPS = json.load(f)
except:
    APPS = {}

def speak(text):
    """Hablar usando termux-tts-speak"""
    print(f"JARVIS: {text}")
    try:
        subprocess.run(
            ["termux-tts-speak", text],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
    except Exception as e:
        print(f"[Error TTS] {e}")

def listen(timeout=8):
    """Escuchar con termux-speech-to-text"""
    print("Escuchando...")
    try:
        result = subprocess.run(
            ["termux-speech-to-text"],
            capture_output=True,
            text=True,
            timeout=timeout + 5
        )
        text = result.stdout.strip().lower()
        if text:
            print(f"Tú: {text}")
            return text
        return ""
    except subprocess.TimeoutExpired:
        print("Tiempo de escucha agotado")
        return ""
    except Exception as e:
        print(f"[Error STT] {e}")
        return ""

def open_app(package):
    """Abrir aplicación por package name"""
    try:
        subprocess.run(
            ["am", "start", "-n", f"{package}/.MainActivity"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        # Método más compatible
        subprocess.run(
            ["am", "start", "-a", "android.intent.action.MAIN",
             "-c", "android.intent.category.LAUNCHER", package],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return True
    except:
        try:
            subprocess.run(["termux-open", f"package:{package}"], check=False)
            return True
        except:
            return False

def get_battery():
    try:
        out = subprocess.check_output(["termux-battery-status"], text=True)
        data = json.loads(out)
        percent = data.get("percentage", "?")
        status = data.get("status", "")
        return f"La batería está al {percent} por ciento. Estado: {status}"
    except:
        return "No pude obtener el estado de la batería"

def get_time():
    now = datetime.now()
    return f"Son las {now.strftime('%H:%M')} del {now.strftime('%d de %B')}"

def process_command(text):
    text = text.lower().strip()

    # Salir
    if any(w in text for w in ["salir", "apagar", "adios", "adiós", "bye", "cerrar jarvis"]):
        speak("Hasta luego. Apagando Jarvis.")
        return False

    # Saludos
    if any(w in text for w in ["hola", "hey jarvis", "buenos días", "buenas tardes", "buenas noches"]):
        speak("Hola. ¿En qué te puedo ayudar?")
        return True

    # Hora
    if any(w in text for w in ["hora", "qué hora", "que hora", "time"]):
        speak(get_time())
        return True

    # Batería
    if any(w in text for w in ["batería", "bateria", "battery", "carga"]):
        speak(get_battery())
        return True

    # Abrir aplicaciones
    for name, package in APPS.items():
        if name in text or f"abrir {name}" in text or f"abre {name}" in text:
            speak(f"Abriendo {name}")
            success = open_app(package)
            if not success:
                # Intento alternativo
                subprocess.run(["am", "start", "-a", "android.intent.action.MAIN", package], 
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True

    # Comando genérico "abrir X"
    match = re.search(r"(abrir|abre|open)\s+(.+)", text)
    if match:
        app_name = match.group(2).strip()
        if app_name in APPS:
            speak(f"Abriendo {app_name}")
            open_app(APPS[app_name])
        else:
            speak(f"No tengo registrada la aplicación {app_name}. Puedes agregarla en config/apps.json")
        return True

    # Respuesta por defecto
    speak("No entendí el comando. Prueba con: abrir whatsapp, qué hora es, o batería.")
    return True

def main():
    speak("Jarvis activado. Di un comando.")
    
    while True:
        try:
            command = listen()
            if not command:
                continue
            
            if not process_command(command):
                break
                
            time.sleep(0.5)
            
        except KeyboardInterrupt:
            speak("Hasta luego.")
            break
        except Exception as e:
            print(f"Error: {e}")
            time.sleep(1)

if __name__ == "__main__":
    main()
