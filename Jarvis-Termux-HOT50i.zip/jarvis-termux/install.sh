#!/data/data/com.termux/files/usr/bin/bash

echo "======================================"
echo "  Instalando JARVIS para Termux"
echo "  Optimizado para Infinix HOT 50i"
echo "======================================"

# Actualizar e instalar dependencias
pkg update -y
pkg upgrade -y
pkg install -y python termux-api espeak sox

# Instalar librerías Python
pip install --upgrade pip
pip install requests

# Dar permisos de ejecución
chmod +x jarvis.py
chmod +x scripts/*.sh 2>/dev/null || true

# Crear acceso directo
mkdir -p $PREFIX/bin
cp jarvis.py $PREFIX/bin/jarvis
chmod +x $PREFIX/bin/jarvis

echo ""
echo "✅ Instalación terminada."
echo ""
echo "Para iniciar escribe:"
echo "   jarvis"
echo ""
echo "o"
echo "   python jarvis.py"
echo ""
echo "Asegúrate de haber otorgado permisos de micrófono a Termux:API"
echo "======================================"
