#!/usr/bin/env python3
"""Jarvis para Termux (Android). Solo usa la libreria estandar de Python."""
import json, os, subprocess, sys, urllib.request, urllib.error, urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(HERE, "config.json"), encoding="utf-8") as f:
    CFG = json.load(f)

API_KEY = os.environ.get("ANTHROPIC_API_KEY") or CFG.get("api_key", "")
MODEL = CFG.get("model", "claude-haiku-5-5")
LANG = CFG.get("idioma_voz", "es")
APPS = {k.lower(): v for k, v in CFG.get("apps", {}).items()}

SYSTEM = f"""Eres Jarvis, un asistente de voz que vive en el telefono Android del usuario.
Responde SIEMPRE y SOLO con un JSON valido, sin texto extra ni markdown:
{{"say": "lo que dices en voz alta (corto, en espanol)", "action": {{...}}}}

Acciones posibles en "action" (usa {{"type":"none"}} si no hace falta ninguna):
- {{"type":"open_app","app":"nombre"}}  apps conocidas: {", ".join(APPS)}
- {{"type":"open_url","url":"https://..."}}
- {{"type":"search","query":"texto"}}  busca en Google
- {{"type":"dial","number":"+000000000"}}  abre el marcador con ese numero
- {{"type":"torch","on":true}}
- {{"type":"set_clipboard","text":"..."}}
- {{"type":"read","what":"battery|notifications|clipboard|location"}}  lee datos del telefono;
  recibiras el resultado en el siguiente mensaje y entonces respondes con "say".
No inventes acciones fuera de esta lista. Si no puedes hacer algo, dilo en "say"."""


def sh(cmd, timeout=60):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (r.stdout or "").strip()
    except Exception as e:
        return f"error: {e}"


def listen():
    return sh(["termux-speech-to-text"], timeout=40)


def speak(text):
    print(f"Jarvis: {text}")
    sh(["termux-tts-speak", "-l", LANG, text], timeout=120)


def ask_claude(history):
    body = json.dumps({
        "model": MODEL, "max_tokens": 500,
        "system": SYSTEM, "messages": history,
    }).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages", data=body, method="POST",
        headers={"content-type": "application/json",
                 "x-api-key": API_KEY, "anthropic-version": "2023-06-01"})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            data = json.load(r)
    except urllib.error.HTTPError as e:
        return {"say": f"Error de la API {e.code}", "action": {"type": "none"}}
    except Exception as e:
        return {"say": "No pude conectarme a internet.", "action": {"type": "none"}}
    text = "".join(b.get("text", "") for b in data.get("content", []))
    text = text.strip().strip("`")
    if text.startswith("json"):
        text = text[4:]
    try:
        return json.loads(text)
    except Exception:
        return {"say": text or "No entendi.", "action": {"type": "none"}}


def open_app(name):
    pkg = APPS.get(name.lower().strip(), name)
    sh(["am", "start", "-a", "android.intent.action.MAIN",
        "-c", "android.intent.category.LAUNCHER", "-p", pkg])


def do_action(a):
    """Devuelve texto con datos si fue una lectura, o None."""
    t = a.get("type", "none")
    if t == "open_app":
        open_app(a.get("app", ""))
    elif t == "open_url":
        sh(["termux-open-url", a.get("url", "")])
    elif t == "search":
        sh(["termux-open-url",
            "https://www.google.com/search?q=" + urllib.parse.quote(a.get("query", ""))])
    elif t == "dial":
        sh(["am", "start", "-a", "android.intent.action.DIAL",
            "-d", "tel:" + a.get("number", "")])
    elif t == "torch":
        sh(["termux-torch", "on" if a.get("on", True) else "off"])
    elif t == "set_clipboard":
        sh(["termux-clipboard-set", a.get("text", "")])
    elif t == "read":
        w = a.get("what")
        if w == "battery":
            return sh(["termux-battery-status"])
        if w == "notifications":
            return sh(["termux-notification-list"])[:3000]
        if w == "clipboard":
            return sh(["termux-clipboard-get"])
        if w == "location":
            return sh(["termux-location", "-p", "network"], timeout=30)
    return None


def handle(user_text, history):
    history.append({"role": "user", "content": user_text})
    for _ in range(3):
        reply = ask_claude(history)
        history.append({"role": "assistant", "content": json.dumps(reply, ensure_ascii=False)})
        action = reply.get("action") or {"type": "none"}
        result = do_action(action)
        if result is not None:
            history.append({"role": "user", "content": f"RESULTADO: {result}"})
            continue
        speak(reply.get("say", ""))
        return
    speak("No pude completar eso.")
    del history[:-12]


def main():
    if not API_KEY:
        sys.exit("Falta la clave: edita config.json o usa export ANTHROPIC_API_KEY=...")
    once = "--once" in sys.argv
    history = []
    speak("Listo.")
    while True:
        if once:
            text = listen()
        else:
            entrada = input("\n[Enter = hablar | o escribe | 'salir']: ").strip()
            if entrada.lower() in ("salir", "exit", "q"):
                break
            text = entrada or listen()
        if not text:
            print("(no escuche nada)")
            if once:
                break
            continue
        print(f"Tu: {text}")
        if text.lower().strip() in ("salir", "adios", "adiós"):
            speak("Hasta luego.")
            break
        handle(text, history)
        history[:] = history[-12:]
        if once:
            break


if __name__ == "__main__":
    main()
