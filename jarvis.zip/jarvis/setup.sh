#!/data/data/com.termux/files/usr/bin/bash
pkg update -y && pkg install -y python termux-api
termux-setup-storage
mkdir -p ~/.shortcuts
printf '#!/data/data/com.termux/files/usr/bin/bash\npython %s/jarvis.py --once\n' "$(pwd)" > ~/.shortcuts/Jarvis
chmod +x ~/.shortcuts/Jarvis
echo "Listo. Ejecuta: python jarvis.py"
